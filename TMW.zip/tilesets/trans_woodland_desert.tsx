<?xml version="1.0" encoding="UTF-8"?>
<tileset name="trans_woodland_desert" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/trans_woodland_desert.png" width="512" height="256"/>
</tileset>
