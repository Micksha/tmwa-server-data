<?xml version="1.0" encoding="UTF-8"?>
<tileset name="snow_ground" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/snow_ground.png" width="352" height="224"/>
</tileset>
