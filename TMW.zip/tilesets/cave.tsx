<?xml version="1.0" encoding="UTF-8"?>
<tileset name="cave" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/cave.png" width="512" height="256"/>
</tileset>
