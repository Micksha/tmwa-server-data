<?xml version="1.0" encoding="UTF-8"?>
<tileset name="forge_x4" tilewidth="32" tileheight="128">
 <image source="../graphics/tiles/forge_x4.png" width="96" height="128"/>
</tileset>
