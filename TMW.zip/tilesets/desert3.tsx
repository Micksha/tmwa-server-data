<?xml version="1.0" encoding="UTF-8"?>
<tileset name="desert3" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/desert3.png" width="320" height="256"/>
</tileset>
